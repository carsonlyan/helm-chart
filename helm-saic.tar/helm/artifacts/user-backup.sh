#!/bin/bash

mkdir -p /home/root/.userbackup/
cp -f /etc/passwd /etc/shadow /etc/group /home/root/.userbackup

hadoop fs -put -f /etc/passwd /etc/shadow /etc/group /user/root/.userbackup/
